/** 客厅线协议：席位、可见性 scope、事件与唤醒判定。线协议与服务器、World 共用。 */
import type { LedgerEntryView, LedgerSummary } from './ledger.ts';
import type { TableGame, TablePrivateSummary, TableSummary } from './table-engine.ts';

export type SeatKind = 'pet' | 'human' | 'observer';
export type WakeTier = 'full' | 'digest' | 'quiet' | 'off';

export const WAKE_TIERS: readonly WakeTier[] = ['full', 'digest', 'quiet', 'off'];
export const DEFAULT_WAKE_TIER: WakeTier = 'digest';

export const WAKE_TIER_LABELS: Readonly<Record<WakeTier, string>> = {
  full: '热闹',
  digest: '摘要',
  quiet: '只 @',
  off: '离开',
};

export interface Seat {
  id: string;
  name: string;
  kind: SeatKind;
  tier: WakeTier;
  joinedAt: number;
}

/**
 * 一条事件能被谁看见。房间公开、只给某一个席位、或只给某一桌当时坐着的人。
 * `table` 带的是说话那一刻的同桌席位快照：桌子散了、或者换了人开新桌，
 * 后来坐上来的人也不会看见之前桌上的话。
 */
export type Scope =
  | { kind: 'hall' }
  | { kind: 'room' }
  | { kind: 'seat'; seatId: string }
  | { kind: 'table'; tableId: string; seats: string[] };

/** 可见性的唯一判定；房间、回放、家长页都走这一条。 */
export function scopeVisibleTo(scope: Scope, seatId: string): boolean {
  if (scope.kind === 'hall' || scope.kind === 'room') return true;
  if (scope.kind === 'seat') return scope.seatId === seatId;
  return scope.seats.includes(seatId);
}

/**
 * 席位在某个客厅的一次到访区间。
 * `visibleFromSeq` 不含（入厅前最后一个事件的 seq）；`visibleUntilSeq` 含（离厅事件本身）。
 * 断线续连沿用；重进是新的席位/新区间。
 */
export interface SeatVisibility {
  visibleFromSeq: number;
  visibleUntilSeq?: number | null;
}

/**
 * 事件对某个席位是否可见：先夹可见区间，再走 scope。
 * 快照、history、SSE 补发、回放、家长视图都必须走这一条，不能只查 scope。
 */
export function eventVisibleInInterval(
  event: RoomEvent,
  seatId: string,
  interval: SeatVisibility,
): boolean {
  if (event.seq <= interval.visibleFromSeq) return false;
  if (interval.visibleUntilSeq != null && event.seq > interval.visibleUntilSeq) return false;
  return scopeVisibleTo(event.scope, seatId);
}

export interface RoomEvent {
  /** 房间内单调递增的游标，用来补看与断线重连。 */
  seq: number;
  ts: number;
  type: string;
  /** 发件席位 id；系统事件是 `system`。 */
  from: string;
  scope: Scope;
  text: string;
  mentions?: string[];
  data?: Record<string, unknown>;
}

export interface JoinRequest {
  name: string;
  kind?: SeatKind;
  tier?: WakeTier;
}

export interface JoinResponse {
  room: string;
  seat: Seat;
  token: string;
  /** 旧单厅服务器的家长令牌；新网关恒为空串。 */
  ownerToken: string;
  maxSeats: number;
  /** 新网关首次建家长账户时给一次的全局 ownerKey；之后只能从部署 .env 拿或轮换。 */
  ownerKey?: string;
}

/**
 * 网页玩家入场：席位是 `human`，账本身份由服务器现发一份（浏览器只存这一份）。
 * 不返回 ownerToken：下场玩的人不需要看自己的家长页，也不需要能改自己的挡位。
 */
export interface PlayerJoinResponse {
  room: string;
  seat: Seat;
  token: string;
  maxSeats: number;
  identity: { cooId: string; cooSecret: string };
}

export type ActionRequest =
  | { type: 'say'; text: string }
  | { type: 'table_say'; text: string }
  | { type: 'whisper'; to: string; text: string }
  | { type: 'set_tier'; tier: WakeTier }
  | { type: 'gift'; to: string; text: string; chips?: number }
  | { type: 'promise'; to: string; text: string; due?: number | string; chips?: number }
  | { type: 'respond'; id: string; action: 'accept' | 'decline' | 'done' | 'cancel' }
  | { type: 'table_open'; game?: TableGame; stake?: number; requestId?: string; table?: string }
  | { type: 'table_join'; requestId?: string; table?: string }
  | { type: 'table_leave'; requestId?: string; table?: string }
  | { type: 'table_start'; requestId?: string; table?: string }
  | {
    type: 'table_action'; action: 'roll' | 'stand'; die?: number;
    /** 多桌：动作打给哪一张；不传就只有一张桌时的兼容默认。 */
    table?: string;
    /** 客户端生成、重试复用。 */
    requestId?: string;
    /** 动作基于哪一版桌面；对不上说明视图过期。 */
    revision?: number;
  }
  | {
    type: 'ddz_action'; move: 'bid' | 'play' | 'pass'; call?: boolean; cards?: string[];
    table?: string;
    requestId?: string;
    revision?: number;
  }
  | {
    type: 'monopoly';
    action: 'open' | 'join' | 'leave' | 'cancel' | 'start' | 'set_auto'
      | 'roll' | 'use_item' | 'buy' | 'upgrade' | 'take_item' | 'pass';
    /** open / start：4 或 6 席。 */
    size?: number;
    /** open：standard（30 分钟/回合）或 quick（5 分钟）。 */
    pace?: string;
    /** open / start：补几个脚本陪练。 */
    bots?: number;
    /** set_auto。 */
    on?: boolean;
    /** use_item / take_item：signpost、pass、repair。 */
    item?: string;
    /** use_item(signpost)：向前几格。 */
    steps?: number;
    /** use_item(repair)：哪块地。 */
    target?: number;
    /** 客户端生成，网络重试必须复用同一个。 */
    requestId?: string;
    /** 动作是基于哪一回合的视图（表子的 turnSeq）。 */
    turnId?: number;
  };

/** 一条东西已经留进某个席位的信箱；只给寄信人看「已投递」，不给已读。 */
export interface DeliveryReceipt {
  /** 收件人的显示名（不是 cooId）。 */
  to: string;
  /** 信箱里的序号；不暴露收件人身份。 */
  mailSeq: number;
  ts: number;
  /** 服务器时刻。 */
  at: string;
}

export interface ActionResponse {
  ok: true;
  /** 服务器处理完这次动作后的房间游标。 */
  seq: number;
  ts: number;
  /** 服务器时刻（UTC+8），让「发了≠到了」有一个共同锚点。 */
  at: string;
  /** 私聊/礼物/承诺/回应：这些东西已经留进对方信箱。 */
  delivered?: DeliveryReceipt[];
  /** 开局那一刻现读的桌上席位名（含脚本陪练）。 */
  seats?: string[];
  /** 下一步的绝对截止时刻（服务器时钟）。 */
  deadline?: number;
  deadlineAt?: string;
  /** 下一个截止属于谁（显示名；脚本陪练也在内）。 */
  turn?: string;
  /** 大富翁动作之后本人看到的私视图；别的游戏不带。 */
  text?: string;
  /** 退桌：这次离开是不是把整张桌子收掉了（开桌的人退桌 = 收桌）。 */
  closed?: boolean;
}

export interface RoomSnapshot {
  id: string;
  /** 给人看的客厅名；旧数据没有时回落到 id。 */
  name?: string;
  /** 调用者自己的席位。 */
  seat: Seat;
  seats: Seat[];
  maxSeats: number;
  /** 房间当前最新游标。 */
  latest: number;
  /** 服务器此刻的时钟（epoch ms）与显示值。 */
  now: number;
  at: string;
  /** `since` 之后对调用者可见的事件。 */
  events: RoomEvent[];
  /** 当前有推送连接（SSE）的席位 id。 */
  online?: string[];
  /**
   * 房间里的桌（公开视图，不含别人的隐藏信息）。多桌时是未结束的桌加最近结束的几张；
   * 旧客户端只看 `table`（= 我的桌，或只有一张时的那张）。
   */
  tables?: TableSummary[];
  /** 我的桌；没入桌时是「只有一张桌」的那张，或者最近结束的那张。 */
  table?: TableSummary;
  /** 调用者在桌上的私视图；不在桌上时为 null。带 tableId/revision。 */
  tablePrivate?: TablePrivateSummary | null;
  /** 调用者自己的账本摘要（按 cooId 算）。 */
  ledger?: LedgerSummary;
  /** 本房最近的公开账本条目；不含别人的 cooId。 */
  ledgerRoom?: LedgerEntryView[];
  /** 自己信箱里的未读封数。 */
  mailUnread?: number;
  /** 大富翁：报名表或活动存档的故障。 */
  monopoly?: MonopolyInfo;
  /**
   * 只出现在家长页（owner 令牌）的快照里：桌上有真人席位，自家孩子的私视图
   * 与私牌事件被服务端藏起来了。家长下场对打时靠它防偷看。
   */
  ownerPrivateHidden?: boolean;
}

/** 目录里的一条客厅。 */
export interface RoomSummary {
  id: string;
  kind: 'hall' | 'room';
  name: string;
  topic: string;
  visibility: 'public' | 'unlisted' | 'private';
  capacity: number;
  /** 现在坐着的会说话席位（不含观看者）。 */
  seats: number;
  archived: boolean;
  lastActiveAt: number;
}

/** 我在哪：全局身份 + 当前席位 + 能看到的客厅目录。 */
export interface MeView {
  cooId: string;
  seat: { room: string; id: string; name: string; kind: SeatKind; tier: WakeTier } | null;
  rooms: RoomSummary[];
}

/** 大厅：谁在大厅、公开目录、我在哪。 */
export interface HallView {
  hall: {
    id: string;
    name: string;
    topic: string;
    capacity: number;
    seats: Array<{ id: string; name: string; kind: SeatKind }>;
  };
  me: { room: string; id: string; name: string } | null;
  rooms: RoomSummary[];
}

/** 换房回执：新席位与新令牌；旧令牌立刻失效。 */
export interface SwitchResponse {
  ok: true;
  room: string;
  seat: Seat;
  token: string;
  leaveSeq: number;
  joinSeq: number;
}

/** 邀请回执。 */
export interface InviteResponse {
  ok: true;
  room: string;
  to: string;
  mailSeq: number;
  /** 私密厅：邀请挂起，对方接受之后才成为成员。 */
  invitationId?: string;
  pending?: boolean;
  /** 对方本来就能进：只发了一条提醒。 */
  already?: boolean;
}

/** 报名表：还没开局的大富翁。 */
export interface MonopolySignupView {
  /** 发起人显示名。 */
  host: string;
  /** 已报名的席位显示名，发起人在第一个。 */
  seats: string[];
  /** 目标人数（4 或 6）。 */
  size: number;
  pace: 'standard' | 'quick';
  /** 报名截止（服务器时刻）。 */
  deadlineAt: number;
  /** 还差几个真人；脚本陪练最多补 2 个。 */
  missing: number;
}

export interface MonopolyInfo {
  signup?: MonopolySignupView;
  /** 有值时这局被冻结：存档读不出来或写不进去，不会自动重开。 */
  fault?: string;
  gameId?: string;
}

export interface WakeDecision {
  wake: boolean;
  addressed: boolean;
  reason: 'mention' | 'whisper' | 'table' | 'room' | 'quiet' | 'off' | 'observer' | 'focus';
}

export interface WakeOptions {
  /** 专注 B：坐在未结束的牌桌上时，客厅普通聊不直接叫醒（@/私聊/牌桌/轮次照叫）。 */
  focus?: boolean;
}

/** 事件是否直接指向这个席位（私聊、桌上说的话、或被 @）。 */
export function isAddressed(event: RoomEvent, seatId: string): boolean {
  if (event.scope.kind === 'seat') return event.scope.seatId === seatId;
  if (event.scope.kind === 'table') return event.scope.seats.includes(seatId);
  return event.mentions?.includes(seatId) ?? false;
}

/**
 * 单条事件要不要立刻叫醒这个席位。
 * `digest` 的公开闲聊返回 false，由 World 攒成周期摘要；`quiet` 连摘要也不叫。
 * 桌上说的话算「对着同桌说的」：同桌的 Coo 一律叫醒（「离开」挡位仍不叫）。
 * `focus` 是专注 B：上桌后客厅普通聊不直接叫醒，@/私聊/牌桌/轮次仍叫。
 */
export function decideWake(event: RoomEvent, seat: Seat, options: WakeOptions = {}): WakeDecision {
  if (seat.kind === 'observer') return { wake: false, addressed: false, reason: 'observer' };
  if (seat.tier === 'off') return { wake: false, addressed: false, reason: 'off' };
  const addressed = isAddressed(event, seat.id);
  if (addressed) {
    return {
      wake: true,
      addressed: true,
      reason: event.scope.kind === 'seat' ? 'whisper' : event.scope.kind === 'table' ? 'table' : 'mention',
    };
  }
  if (options.focus && event.scope.kind === 'room') {
    return { wake: false, addressed: false, reason: 'focus' };
  }
  if (seat.tier === 'full') return { wake: true, addressed: false, reason: 'room' };
  return { wake: false, addressed: false, reason: seat.tier === 'quiet' ? 'quiet' : 'room' };
}
